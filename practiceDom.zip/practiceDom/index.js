const buttonElement = document.getElementById("add-button");
const listElement = document.getElementById("list");
const nameInputElement = document.getElementById("name-input");
const colorInputElement = document.getElementById("color-input");
const studentElements = document.querySelectorAll(".student")
const greetingButtonElements = document.querySelectorAll(".hello")


const greetingButton = () => {
    const greetingButtonElements = document.querySelectorAll(".hello");
    //console.log(greetingButtonElements) ;

    for (const greetingButtonElement of greetingButtonElements) {
        //console.log(greetingButtonElement);               
        greetingButtonElement.addEventListener('click', () => {

            //console.log(greetingButtonElement.innerHTML)       
            alert(`Привет, ${greetingButtonElement.dataset.name}`)
            //console.log(greetingButtonElement.dataset.name)
        });
    }
};
greetingButton();



//функция добавляет обработчики кликов ко всем элементам с классом.student
const initEventListeners = () => {
    const studentElements = document.querySelectorAll(".student")//(находит все элементы с классом student ) передадим в селектор query..  селектор по классу "student" и сохраним в переменную
    //console.log(studentElements) //возвращает список найденных элементов, возвращает структуру данных как массив

    for (const studentElement of studentElements) {  //перебрать коллекцию(проходит по каждому элементу в цикле)
        //console.log(studentElement);               //вывелись три отдельных элемента для проверки
        studentElement.addEventListener('click', () => {      //на каждый(конкретный) элемент в списке добавим обработчик клика

            //console.log(studentElement.innerHTML)       //при клике в консоль 1 работает //по .innerHTML мы можем получить данные элемента разметки 
            // console.log(studentElement.dataset.color)      //внутри обработчика клика мы можем получить доступ к data атрибутам

        });
    }
};
initEventListeners();


const spanElements = document.querySelectorAll("span")
//console.log (spanElements)

const colorOnclick = () => {
    const spanElements = document.querySelectorAll("span")
    //console.log (spanElements)
    const bodyElement = document.querySelector("body");
    for (const spanElement of spanElements) {  //перебрать коллекцию
        //console.log(spanElement);               //вывелись три отдельных элемента для проверки
        spanElement.addEventListener('click', () => {      //на каждый элемент добавим обработчик клика
            //console.log(1);        //при клике в консоль 1 работает
            bodyElement.style.backgroundColor = "red";
        })
    }
}
colorOnclick()

buttonElement.addEventListener("click", () => {
    nameInputElement.classList.remove("input-error");

    if (nameInputElement.value === "") {
        nameInputElement.classList.add("input-error");
        return;
    }

    listElement.innerHTML =
        listElement.innerHTML +     //добавляем в разметку data атрибут
        `<li class="student"   data-color=" ${colorInputElement.value}">  
        <p class="student-name">
          ${nameInputElement.value}, любимый цвет
          <span style="color: ${colorInputElement.value}"> ${colorInputElement.value}</span>
        </p>
        <button data-name="${nameInputElement.value}">Привет</button>

      </li>`;


    //добавляем сюда внутрь изменения разметки страницы при получении нового элемента в списка из формы, оформив функцию

    initEventListeners();
    colorOnclick()
    greetingButton();

    nameInputElement.value = "";
});







